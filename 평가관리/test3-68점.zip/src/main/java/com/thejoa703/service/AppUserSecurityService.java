package com.thejoa703.service;

import org.springframework.web.multipart.MultipartFile;
import com.thejoa703.dto.*;

public interface AppUserSecurityService {
	public int  insert( MultipartFile file, AppUser dto);  //유저삽입 
	public AppUserAuthDto  readAuth(     String email);  //로그인
	public AppUser         selectEmail(  String email);  //마이페이지
	public int iddouble(String email);
}

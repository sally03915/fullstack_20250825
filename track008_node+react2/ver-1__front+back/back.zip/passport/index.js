// passport/index.js
const passport = require('passport');
const local = require('./local');
const { findUserById } = require('../models/users');

module.exports = () => {
  // 세션에 사용자 PK 저장
  passport.serializeUser((user, done) => {
    done(null, user.APP_USER_ID);
  });

  // 세션에서 PK를 꺼내 DB에서 사용자 조회
  passport.deserializeUser(async (id, done) => {
    try {
      const user = await findUserById(id); // findUserById 구현 필요
      done(null, user);
    } catch (error) {
      console.error('deserializeUser Error:', error);
      done(error);
    }
  });

  // LocalStrategy 등록
  local();
};

■4. controller
1. [passport]  index.js   local.js
2. [router]  user.js
3. curl에서 테스트 - command
 
 
서버 실행1. npx nodemon app.js
→ 서버가 http://localhost:3065에서 실행 중이어야 합니다.

서버 실행2. 컨트롤러 엔드포인트 확인
회원가입: POST /user/register
로그인: POST /user/login
전체 조회: GET /user/
닉네임 수정: PATCH /user/:id/nickname
삭제: DELETE /user/:id


## ✅ 윈도우에서 실행하는 방법

1. **서버 실행**
   ```bash
   node app.js
   ```
   → 서버가 `http://localhost:3065`에서 실행 중이어야 합니다.

2. **CMD 또는 PowerShell 열기**
   - Windows 키 → "cmd" 또는 "powershell" 입력 후 실행

3. **회원가입 테스트**
   ```bash
   curl -X POST http://localhost:3065/user/register ^
     -H "Content-Type: application/json" ^
     -d "{\"email\":\"z@z\",\"password\":\"1234\",\"nickname\":\"테스트유저\",\"mobile\":\"010-1234-5678\",\"mbtiTypeId\":101,\"ufile\":\"profile.png\"}"
   ```
   👉 윈도우에서는 줄바꿈 대신 `^`를 쓰거나 한 줄로 붙여서 실행해야 합니다.

  C:\Users\TJ-BU-703-강사PC>   curl -X POST http://localhost:3065/user/register ^
  More?      -H "Content-Type: application/json" ^
  More?      -d "{\"email\":\"z@z\",\"password\":\"1234\",\"nickname\":\"테스트유저\",\"mobile\":\"010-1234-5678\",\"mbtiTypeId\":101,\"ufile\":\"profile.png\"}"
  회원가입 성공


4. **로그인 테스트**
   ```bash
   curl -X POST http://localhost:3065/user/login ^
     -H "Content-Type: application/json" ^
     -d "{\"email\":\"1@1\",\"password\":\"1\"}"
   ```

  C:\Users\TJ-BU-703-강사PC>   curl -X POST http://localhost:3065/user/login ^
  More?      -H "Content-Type: application/json" ^
  More?      -d "{\"email\":\"z@z\",\"password\":\"1234\"}"
  {"APP_USER_ID":210,"EMAIL":"z@z","PASSWORD":"$2b$12$tDOnhP0AI0H9B/iIZqlos.D8RniCeA0qEh0OwEExEpw1w40T.Of8G","NICKNAME":"테스트유저","MOBILE":"010-1234-5678","MBTI_TYPE_ID":101,"UFILE":"profile.png","CREATED_AT":"2025-12-02T04:53:23.000Z"}
  C:\Users\TJ-BU-703-강사PC>

5. **전체 사용자 조회**
   ```bash
   curl http://localhost:3065/user/
   ```
  C:\Users\TJ-BU-703-강사PC>`curl http://localhost:3065/user/
  [{"APP_USER_ID":161,"EMAIL":"1@1","NICKNAME":"1","MOBILE":"1","MBTI_TYPE_ID":1,"CREATED_AT":"2025-11-28T06:39:07.000Z"},{"APP_USER_ID":194,"EMAIL":"c@c","NICKNAME":"테스트유저","MOBILE":"010-1234-5678","MBTI_TYPE_ID":101,"CREATED_AT":"2025-12-02T00:23:19.000Z"},{"APP_USER_ID":181,"EMAIL":"testuser@example.com","NICKNAME":"테스트유저","MOBILE":"010-1234-5678","MBTI_TYPE_ID":101,"CREATED_AT":"2025-12-01T09:14:45.000Z"},{"APP_USER_ID":188,"EMAIL":"a@a","NICKNAME":"테스트유저","MOBILE":"010-1234-5678","MBTI_TYPE_ID":101,"CREATED_AT":"2025-12-01T09:16:26.000Z"},{"APP_USER_ID":189,"EMAIL":"b@b","NICKNAME":"테스트유저","MOBILE":"010-1234-5678","MBTI_TYPE_ID":101,"CREATED_AT":"2025-12-01T09:16:35.000Z"},{"APP_USER_ID":210,"EMAIL":"z@z","NICKNAME":"테스트유저","MOBILE":"010-1234-5678","MBTI_TYPE_ID":101,"CREATED_AT":"2025-12-02T04:53:23.000Z"}]
  C:\Users\TJ-BU-703-강사PC>`


6. **닉네임 수정**
   ```bash
   curl -X PATCH http://localhost:3065/user/161/nickname ^
     -H "Content-Type: application/json" ^
     -d "{\"nickname\":\"수정된닉네임\"}"
   ```

7. **사용자 삭제**
   ```bash
   curl -X DELETE http://localhost:3065/user/210
   ```
 
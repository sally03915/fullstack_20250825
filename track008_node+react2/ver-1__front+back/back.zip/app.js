const express = require('express');
const cors = require('cors');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const passport = require('passport');
const dotenv = require('dotenv');
const morgan = require('morgan');
const path = require('path');
const hpp = require('hpp');
const helmet = require('helmet');
const oracledb = require('oracledb');

// Swagger 관련 패키지
const swaggerUi = require('swagger-ui-express');
const swaggerJsdoc = require('swagger-jsdoc');

dotenv.config();
const app = express();

// Oracle Client 초기화
oracledb.initOracleClient({ libDir: "C:\\oracle\\instantclient_11_2" });

// DB 커넥션 풀 생성
async function initDB() {
  try {
    await oracledb.createPool({
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      connectString: process.env.DB_CONNECT,
      poolMin: 2,
      poolMax: 10,
      poolIncrement: 1
    });
    console.log('Oracle DB 커넥션 풀 생성 성공');
  } catch (err) {
    console.error('Oracle DB 커넥션 풀 생성 실패', err);
  }
}
initDB();

// Passport 설정
const passportConfig = require('./passport');
passportConfig();

// 환경별 미들웨어
if (process.env.NODE_ENV === 'production') {
  app.use(morgan('combined'));
  app.use(hpp());
  app.use(helmet());
  app.use(cors({
    origin: 'http://thejoa.com',
    credentials: true,
  }));
} else {
  app.use(morgan('dev'));
  app.use(cors({
    origin: true,
    credentials: true,
  }));
}

// 기본 미들웨어
app.use('/', express.static(path.join(__dirname, 'uploads')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser(process.env.COOKIE_SECRET));
app.use(session({
  saveUninitialized: false,
  resave: false,
  secret: process.env.COOKIE_SECRET,
  cookie: {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    domain: process.env.NODE_ENV === 'production' ? '.thejoa.com' : undefined
  },
}));
app.use(passport.initialize());
app.use(passport.session());

// 라우터
const userRouter = require('./routes/user');
app.get('/', (req, res) => res.send('hello express'));
app.use('/user', userRouter);

// Swagger 설정
const swaggerOptions = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'User API',
      version: '1.0.0',
      description: '회원가입, 로그인, 사용자 조회/수정/삭제 API 문서',
    },
  },
  apis: ['./routes/*.js'], // Swagger 주석이 들어간 라우터 파일들
};
const swaggerSpecs = swaggerJsdoc(swaggerOptions);
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpecs));

// 에러 핸들링 미들웨어
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: '서버 오류 발생' });
});

// 서버 실행
const PORT = process.env.PORT || 3065;
app.listen(PORT, () => {
  console.log(`서버 실행 중! (포트: ${PORT})`);
  console.log(`Swagger UI: http://localhost:${PORT}/api-docs`);
});

const express = require('express');
const passport = require('passport');
const isAuthenticated = require('../middlewares/isAuthenticated');
const { createUser, getAllUsers, updateUserNickname, deleteUser } = require('../models/users');

const router = express.Router();

/**
 * @swagger
 * /user/register:
 *   post:
 *     summary: 회원가입
 *     description: 새로운 사용자를 등록합니다.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               email: { type: string }
 *               password: { type: string }
 *               nickname: { type: string }
 *               mobile: { type: string }
 *               mbtiTypeId: { type: integer }
 *               ufile: { type: string }
 *     responses:
 *       201:
 *         description: 회원가입 성공
 */
router.post('/register', async (req, res) => {
  try {
    const { email, password, nickname, mobile, mbtiTypeId, ufile } = req.body;
    await createUser(email, password, nickname, mobile, mbtiTypeId, ufile);
    res.status(201).json({ message: '회원가입 성공' });
  } catch (err) {
    console.error('Register Error:', err);
    res.status(500).json({ message: '회원가입 실패' });
  }
});

/**
 * @swagger
 * /user/login:
 *   post:
 *     summary: 로그인
 *     description: 이메일과 비밀번호로 로그인합니다.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               email: { type: string }
 *               password: { type: string }
 *     responses:
 *       200:
 *         description: 로그인 성공
 *       401:
 *         description: 로그인 실패
 */
router.post('/login', (req, res, next) => {
  passport.authenticate('local', (err, user, info) => {
    if (err) return next(err);
    if (!user) return res.status(401).json({ message: info?.message || '로그인 실패' });

    req.login(user, (loginErr) => {
      if (loginErr) return next(loginErr);
      const { PASSWORD, ...safeUser } = user;
      res.status(200).json(safeUser);
    });
  })(req, res, next);
});

/**
 * @swagger
 * /user/logout:
 *   post:
 *     summary: 로그아웃
 *     description: 현재 로그인된 사용자의 세션을 종료합니다.
 *     responses:
 *       200:
 *         description: 로그아웃 성공
 *       401:
 *         description: 인증 필요
 */
router.post('/logout', isAuthenticated, (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('connect.sid');
    res.json({ message: '로그아웃 성공' });
  });
});

/**
 * @swagger
 * /user/:
 *   get:
 *     summary: 전체 사용자 조회
 *     description: 로그인된 사용자만 전체 사용자 목록을 조회할 수 있습니다.
 *     responses:
 *       200:
 *         description: 사용자 목록 반환
 *       401:
 *         description: 인증 필요
 */
router.get('/', isAuthenticated, async (req, res) => {
  try {
    const users = await getAllUsers();
    res.json(users);
  } catch (err) {
    console.error('GetAllUsers Error:', err);
    res.status(500).json({ message: '사용자 조회 실패' });
  }
});

/**
 * @swagger
 * /user/{id}/nickname:
 *   patch:
 *     summary: 닉네임 수정
 *     description: 특정 사용자의 닉네임을 수정합니다.
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               nickname: { type: string }
 *     responses:
 *       200:
 *         description: 닉네임 수정 완료
 */
router.patch('/:id/nickname', isAuthenticated, async (req, res) => {
  try {
    const { nickname } = req.body;
    await updateUserNickname(req.params.id, nickname);
    res.json({ message: '닉네임 수정 완료' });
  } catch (err) {
    console.error('UpdateNickname Error:', err);
    res.status(500).json({ message: '닉네임 수정 실패' });
  }
});

/**
 * @swagger
 * /user/{id}:
 *   delete:
 *     summary: 사용자 삭제
 *     description: 특정 사용자를 삭제합니다.
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         description: 사용자 삭제 완료
 */
router.delete('/:id', isAuthenticated, async (req, res) => {
  try {
    await deleteUser(req.params.id);
    res.json({ message: '사용자 삭제 완료' });
  } catch (err) {
    console.error('DeleteUser Error:', err);
    res.status(500).json({ message: '사용자 삭제 실패' });
  }
});

module.exports = router;

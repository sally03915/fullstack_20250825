const dbConfig = require('../config/db'); // { user, password, connectString }
const oracledb = require('oracledb');
const bcrypt = require('bcrypt');

// Oracle Instant Client 초기화 (환경에 맞게 경로 수정)
oracledb.initOracleClient({ libDir: "C:\\oracle\\instantclient_11_2" });

// 공통 옵션: 결과를 객체 형태로 반환, 자동 커밋
const options = { outFormat: oracledb.OUT_FORMAT_OBJECT, autoCommit: true };

// 회원가입 (Create)
async function createUser(email, password, nickname, mobile, mbtiTypeId, ufile) {
  let conn;
  try {
    conn = await oracledb.getConnection(dbConfig);
    const hashedPassword = await bcrypt.hash(password, 10);

    await conn.execute(
      `INSERT INTO APPUSER 
        (APP_USER_ID, EMAIL, PASSWORD, NICKNAME, MOBILE, MBTI_TYPE_ID, UFILE, CREATED_AT) 
       VALUES (APPUSER_SEQ.NEXTVAL, :email, :password, :nickname, :mobile, :mbtiTypeId, :ufile, SYSDATE)`,
      { email, password: hashedPassword, nickname, mobile, mbtiTypeId, ufile },
      options
    );
  } catch (err) {
    console.error('createUser Error:', err);
    throw err;
  } finally {
    if (conn) await conn.close();
  }
}

// 사용자 조회 (Read by Email)
async function findUserByEmail(email) {
  let conn;
  try {
    conn = await oracledb.getConnection(dbConfig);
    const result = await conn.execute(
      `SELECT APP_USER_ID, EMAIL, PASSWORD, NICKNAME, MOBILE, MBTI_TYPE_ID, UFILE, CREATED_AT 
       FROM APPUSER WHERE EMAIL = :email`,
      { email },
      options
    );
    return result.rows[0]; // { APP_USER_ID: ..., EMAIL: ..., ... }
  } catch (err) {
    console.error('findUserByEmail Error:', err);
    throw err;
  } finally {
    if (conn) await conn.close();
  }
}

// 로그인 검증 (비밀번호 체크)
async function verifyUser(email, password) {
  const user = await findUserByEmail(email);
  if (!user) return null;

  const match = await bcrypt.compare(password, user.PASSWORD);
  if (!match) return null;

  // 비밀번호가 맞으면 사용자 객체 반환
  return {
    id: user.APP_USER_ID,
    email: user.EMAIL,
    nickname: user.NICKNAME,
  };
}

// 로그아웃은 DB에서 처리할 게 없음 → 라우터에서 req.session.destroy()로 세션 삭제

// 전체 사용자 조회 (테스트용)
async function getAllUsers() {
  let conn;
  try {
    conn = await oracledb.getConnection(dbConfig);
    const result = await conn.execute(
      `SELECT APP_USER_ID, EMAIL, NICKNAME, MOBILE, MBTI_TYPE_ID, CREATED_AT FROM APPUSER`,
      {},
      options
    );
    return result.rows;
  } catch (err) {
    console.error('getAllUsers Error:', err);
    throw err;
  } finally {
    if (conn) await conn.close();
  }
}

// 사용자 닉네임 수정 (Update)
async function updateUserNickname(id, nickname) {
  let conn;
  try {
    conn = await oracledb.getConnection(dbConfig);
    await conn.execute(
      `UPDATE APPUSER SET NICKNAME = :nickname WHERE APP_USER_ID = :id`,
      { nickname, id },
      options
    );
  } catch (err) {
    console.error('updateUserNickname Error:', err);
    throw err;
  } finally {
    if (conn) await conn.close();
  }
}

// 사용자 삭제 (Delete)
async function deleteUser(id) {
  let conn;
  try {
    conn = await oracledb.getConnection(dbConfig);
    await conn.execute(
      `DELETE FROM APPUSER WHERE APP_USER_ID = :id`,
      { id },
      options
    );
  } catch (err) {
    console.error('deleteUser Error:', err);
    throw err;
  } finally {
    if (conn) await conn.close();
  }
}

// 사용자 조회 (Read by ID)
async function findUserById(id) {
  let conn;
  try {
    conn = await oracledb.getConnection(dbConfig);
    const result = await conn.execute(
      `SELECT APP_USER_ID, EMAIL, PASSWORD, NICKNAME, MOBILE, MBTI_TYPE_ID, UFILE, CREATED_AT 
       FROM APPUSER WHERE APP_USER_ID = :id`,
      { id },
      options
    );
    return result.rows[0];
  } catch (err) {
    console.error('findUserById Error:', err);
    throw err;
  } finally {
    if (conn) await conn.close();
  }
}

module.exports = { 
  createUser, 
  findUserByEmail, 
  verifyUser,   // 로그인 검증용 함수 추가
  getAllUsers, 
  updateUserNickname, 
  deleteUser,
  findUserById 
};

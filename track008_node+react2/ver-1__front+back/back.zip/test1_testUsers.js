const {
  createUser,
  findUserByEmail,
  verifyUser,          // 로그인 검증 함수 추가
  getAllUsers,
  updateUserNickname,
  deleteUser,
  findUserById
} = require('./models/users');

async function runTests() {
  try {
    // 1. 회원가입
    await createUser('test@example.com', '1234', '테스터', '01012345678', 1, 'profile.png');
    console.log('✅ createUser 성공');

    // 2. 이메일로 조회
    const userByEmail = await findUserByEmail('test@example.com');
    console.log('✅ findUserByEmail 결과:', userByEmail);

    // 3. 로그인 검증 (비밀번호 맞는 경우)
    const loginUser = await verifyUser('test@example.com', '1234');
    console.log('✅ verifyUser (올바른 비밀번호) 결과:', loginUser);

    // 4. 로그인 검증 (비밀번호 틀린 경우)
    const failLogin = await verifyUser('test@example.com', 'wrongpass');
    console.log('✅ verifyUser (잘못된 비밀번호) 결과:', failLogin);

    // 5. 전체 조회
    const allUsers = await getAllUsers();
    console.log('✅ getAllUsers 결과:', allUsers);

    // 6. 닉네임 수정
    await updateUserNickname(userByEmail.APP_USER_ID, '새닉네임');
    const updatedUser = await findUserById(userByEmail.APP_USER_ID);
    console.log('✅ updateUserNickname 결과:', updatedUser);

    // 7. 삭제
    await deleteUser(userByEmail.APP_USER_ID);
    console.log('✅ deleteUser 성공');

    // 삭제 후 확인
    const deletedUser = await findUserById(userByEmail.APP_USER_ID);
    console.log('✅ findUserById (삭제 후):', deletedUser);
  } catch (err) {
    console.error('❌ 테스트 중 오류 발생:', err);
  }
}

runTests();

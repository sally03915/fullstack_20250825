// npx jest reducers/user.test.js

// PS D:\hyojung\test\test1\front> npx jest reducers/user.test.js D:\hyojung\test\test1\front>
//  PASS  reducers/user.test.js
//   user reducer
//     √ should handle LOG_IN_REQUEST (8 ms)
//     √ should handle LOG_IN_SUCCESS (4 ms)
//     √ should handle LOG_IN_FAILURE (3 ms)
//     √ should handle LOG_OUT_REQUEST (2 ms)
//     √ should handle LOG_OUT_SUCCESS (2 ms)
//     √ should handle LOG_OUT_FAILURE (1 ms)
//     √ should handle SIGN_UP_SUCCESS (1 ms)
//     √ should handle LOAD_USERS_SUCCESS
//     √ should handle UPDATE_NICKNAME_SUCCESS
//     √ should handle DELETE_USER_SUCCESS
//     √ should handle DELETE_USER_SUCCESS and clear me if self deleted (1 ms)

// Test Suites: 1 passed, 1 total
// Tests:       11 passed, 11 total
// Snapshots:   0 total
// Time:        3.672 s
// Ran all test suites matching /reducers\\user.test.js/i.     
// PS D:\hyojung\test\test1\front>

import reducer, {
  initialState,
  LOG_IN_REQUEST, LOG_IN_SUCCESS, LOG_IN_FAILURE,
  LOG_OUT_REQUEST, LOG_OUT_SUCCESS, LOG_OUT_FAILURE,
  SIGN_UP_REQUEST, SIGN_UP_SUCCESS, SIGN_UP_FAILURE,
  LOAD_USERS_REQUEST, LOAD_USERS_SUCCESS, LOAD_USERS_FAILURE,
  UPDATE_NICKNAME_REQUEST, UPDATE_NICKNAME_SUCCESS, UPDATE_NICKNAME_FAILURE,
  DELETE_USER_REQUEST, DELETE_USER_SUCCESS, DELETE_USER_FAILURE,
} from './user';

describe('user reducer', () => {
  it('should handle LOG_IN_REQUEST', () => {
    const state = reducer(initialState, { type: LOG_IN_REQUEST });
    expect(state.isLoading).toBe(true);
  });

  it('should handle LOG_IN_SUCCESS', () => {
    const fakeUser = { id: 1, email: 'test@example.com', nickname: '홍길동' };
    const state = reducer(initialState, { type: LOG_IN_SUCCESS, data: fakeUser });
    expect(state.me).toEqual(fakeUser);
  });

  it('should handle LOG_IN_FAILURE', () => {
    const state = reducer(initialState, { type: LOG_IN_FAILURE, error: '로그인 실패' });
    expect(state.error).toBe('로그인 실패');
    expect(state.isLoading).toBe(false);
  });

  it('should handle LOG_OUT_REQUEST', () => {
    const state = reducer(initialState, { type: LOG_OUT_REQUEST });
    expect(state.isLoading).toBe(true);
  });

  it('should handle LOG_OUT_SUCCESS', () => {
    const prevState = { ...initialState, me: { id: 1, email: 'test@example.com' } };
    const state = reducer(prevState, { type: LOG_OUT_SUCCESS });
    expect(state.me).toBeNull();
    expect(state.isLoading).toBe(false);
  });

  it('should handle LOG_OUT_FAILURE', () => {
    const state = reducer(initialState, { type: LOG_OUT_FAILURE, error: '로그아웃 실패' });
    expect(state.error).toBe('로그아웃 실패');
    expect(state.isLoading).toBe(false);
  });

  it('should handle SIGN_UP_SUCCESS', () => {
    const state = reducer(initialState, { type: SIGN_UP_SUCCESS });
    expect(state.isLoading).toBe(false);
    expect(state.signUpDone).toBe(true);
  });

  it('should handle LOAD_USERS_SUCCESS', () => {
    const fakeUsers = [{ id: 1, email: 'a@test.com', nickname: 'old' }];
    const state = reducer(initialState, { type: LOAD_USERS_SUCCESS, data: fakeUsers });
    expect(state.users).toEqual(fakeUsers);
  });

  it('should handle UPDATE_NICKNAME_SUCCESS', () => {
    const prevState = { 
      ...initialState, 
      me: { id: 1, nickname: 'old' },
      users: [{ id: 1, nickname: 'old' }]
    };
    const state = reducer(prevState, { type: UPDATE_NICKNAME_SUCCESS, data: { id: 1, nickname: 'new' } });
    expect(state.me.nickname).toBe('new');
    expect(state.users[0].nickname).toBe('new');
  });

  it('should handle DELETE_USER_SUCCESS', () => {
    const prevState = { ...initialState, users: [{ id: 1 }, { id: 2 }] };
    const state = reducer(prevState, { type: DELETE_USER_SUCCESS, data: { id: 1 } });
    expect(state.users).toEqual([{ id: 2 }]);
  });

  it('should handle DELETE_USER_SUCCESS and clear me if self deleted', () => {
    const prevState = { 
      ...initialState, 
      me: { id: 1 }, 
      users: [{ id: 1 }, { id: 2 }] 
    };
    const state = reducer(prevState, { type: DELETE_USER_SUCCESS, data: { id: 1 } });
    expect(state.users).toEqual([{ id: 2 }]);
    expect(state.me).toBeNull();
  });
});

// React와 Redux 관련 훅 불러오기
import { useDispatch, useSelector } from 'react-redux';
// 사용자 관련 액션 타입 불러오기 (조회, 삭제, 닉네임 수정, 로그아웃)
import { LOAD_USERS_REQUEST, DELETE_USER_REQUEST, UPDATE_NICKNAME_REQUEST, LOG_OUT_REQUEST } from '../reducers/user';
// React 훅 (상태 관리, 사이드 이펙트)
import { useEffect, useState } from 'react';
// Next.js 라우팅을 위한 Link 컴포넌트
import Link from 'next/link';
// 페이지 이동을 위한 Next.js Router
import { useRouter } from 'next/router';

export default function UsersPage() {
  // Redux 액션을 dispatch하기 위한 함수
  const dispatch = useDispatch();
  // Next.js Router 객체
  const router = useRouter();

  // Redux store에서 user 상태 가져오기
  // users: 사용자 목록, isLoading: 로딩 여부, error: 에러 메시지, me: 로그인된 사용자 정보
  const { users, isLoading, error, me } = useSelector((state) => state.user);

  // 닉네임 수정 모드 상태 관리
  const [editId, setEditId] = useState(null);       // 현재 수정 중인 사용자 id
  const [newNickname, setNewNickname] = useState(''); // 입력한 새 닉네임

  // 컴포넌트가 처음 렌더링될 때 실행
  useEffect(() => {
    if (!me) {
      // 로그인 안 되어 있으면 로그인 페이지로 이동
      router.push('/login');
    } else {
      // 로그인 되어 있으면 사용자 목록 불러오기
      dispatch({ type: LOAD_USERS_REQUEST });
    }
  }, [dispatch, me, router]);

  // 사용자 삭제 버튼 클릭 시 실행
  const onDelete = (id) => {
    dispatch({ type: DELETE_USER_REQUEST, data: { id } });
  };

  // 닉네임 수정 버튼 클릭 시 실행
  const onEdit = (id) => {
    setEditId(id); // 수정할 사용자 id 저장
  };

  // 닉네임 수정 완료 버튼 클릭 시 실행
  const onUpdateNickname = (id) => {
    dispatch({ type: UPDATE_NICKNAME_REQUEST, data: { id, nickname: newNickname } });
    setEditId(null);       // 수정 모드 종료
    setNewNickname('');    // 입력창 초기화
  };

  // 로그아웃 버튼 클릭 시 실행
  const onLogout = () => {
    dispatch({ type: LOG_OUT_REQUEST });
  };

  // 실제 화면 렌더링
  return (
    <div className=""> 
      {/* 상단 헤더 영역 */}
      <div className="p-5 bg-primary text-white text-center">
        <h1>사용자 목록 페이지</h1>
        <p>로그인 후만 접근 가능</p> 
      </div>

      {/* 네비게이션바 */}
      <nav className="navbar navbar-expand-sm bg-dark navbar-dark">
        <div className="container-fluid">
          <ul className="navbar-nav">
            {/* 홈 링크 */}
            <li className="nav-item">
              <Link href="/users"><a className="nav-link text-white">Home</a></Link>
            </li>
            {/* 로그인 상태에 따라 조건부 렌더링 */}
            {!me ? (
              <>
                {/* 로그인/회원가입 링크 */}
                <li className="nav-item"><Link href="/login"><a className="nav-link text-white">로그인</a></Link></li>
                <li className="nav-item"><Link href="/signup"><a className="nav-link text-white">회원가입</a></Link></li>
              </>
            ) : (
              // 로그인 상태면 로그아웃 버튼 표시
              <li className="nav-item">
                <button className="btn btn-link nav-link text-white" onClick={onLogout}>
                  로그아웃
                </button>
              </li>
            )}
          </ul>
        </div>
      </nav>
  
      {/* 본문 영역 */}
      <div className="container mt-4">
        <h1 className="mb-3">사용자 목록</h1>

        {/* 로딩/에러 메시지 표시 */}
        {isLoading && <div className="alert alert-info">로딩 중...</div>}
        {error && <div className="alert alert-danger">{error}</div>}

        {/* 사용자 목록 테이블 */}
        <table className="table table-striped table-bordered table-hover">
          <thead>
            <tr>
              <th>이메일</th>
              <th>닉네임</th>
              <th>액션</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id}>
                <td>{u.email}</td>
                <td>
                  {/* 현재 수정 중인 사용자라면 입력창 표시 */}
                  {editId === u.id ? (
                    <input
                      className="form-control"
                      value={newNickname}
                      onChange={(e) => setNewNickname(e.target.value)}
                      placeholder="새 닉네임"
                    />
                  ) : (
                    u.nickname
                  )}
                </td>
                <td>
                  {/* 수정 중이면 '수정 완료' 버튼, 아니면 '닉네임 수정' 버튼 */}
                  {editId === u.id ? (
                    <button
                      className="btn btn-success btn-sm me-2"
                      onClick={() => onUpdateNickname(u.id)}
                    >
                      수정 완료
                    </button>
                  ) : (
                    <button
                      className="btn btn-primary btn-sm me-2"
                      onClick={() => onEdit(u.id)}
                    >
                      닉네임 수정
                    </button>
                  )}
                  {/* 삭제 버튼 */}
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => onDelete(u.id)}
                  >
                    삭제
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// pages/_app.js
import { wrapper } from '../store/configureStore';
import 'bootstrap/dist/css/bootstrap.min.css';  // Bootstrap CSS 추가
import '../styles/globals.css';                 // 기존 글로벌 스타일

function MyApp({ Component, pageProps }) {
  return <Component {...pageProps} />;
}

export default wrapper.withRedux(MyApp);

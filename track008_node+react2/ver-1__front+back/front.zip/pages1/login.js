// pages/login.js
import { useDispatch, useSelector } from 'react-redux';
import { LOG_IN_REQUEST } from '../reducers/user';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';

export default function LoginPage() {
  // Redux dispatch 함수 가져오기
  const dispatch = useDispatch();
  // Next.js 라우터 → 페이지 이동에 사용
  const router = useRouter();
  // Redux store에서 로그인 상태(me), 로딩 여부, 에러 가져오기
  const { me, isLoading, error } = useSelector((state) => state.user);

  // 입력값 상태 관리 (이메일, 비밀번호)
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // 로그인 버튼 클릭 시 실행되는 함수
  const onSubmit = (e) => {
    e.preventDefault(); // 기본 폼 제출 막기
    // Redux 액션 dispatch → saga → 서버 요청
    dispatch({ type: LOG_IN_REQUEST, data: { email, password } });
  };

  // 로그인 성공 시 me 값이 채워짐 → /users 페이지로 이동
  useEffect(() => {
    if (me) {
      router.push('/users');
    }
  }, [me, router]);

  return (
    <div>
      {/* 헤더 영역 */}
      <div className="p-5 bg-primary text-white text-center">
        <h1>로그인 페이지</h1>
        <p>Bootstrap 5 스타일 적용</p>
      </div>

      {/* 네비게이션바 */}
      <nav className="navbar navbar-expand-sm bg-dark navbar-dark">
        <div className="container-fluid">
          <ul className="navbar-nav">
            <li className="nav-item"><Link href="/users"><a className="nav-link text-white">Home</a></Link></li>
            <li className="nav-item"><Link href="/login"><a className="nav-link text-white">로그인</a></Link></li>
            <li className="nav-item"><Link href="/signup"><a className="nav-link text-white">회원가입</a></Link></li>
          </ul>
        </div>
      </nav>

      {/* 본문: 로그인 폼 */}
      <div className="container mt-4">
        <h2 className="mb-3">로그인</h2>
        <form onSubmit={onSubmit} className="w-50 mx-auto">
          {/* 이메일 입력 */}
          <div className="mb-3">
            <input
              type="email"
              className="form-control"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="이메일"
            />
          </div>
          {/* 비밀번호 입력 */}
          <div className="mb-3">
            <input
              type="password"
              className="form-control"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="비밀번호"
            />
          </div>
          {/* 로그인 버튼 */}
          <button type="submit" className="btn btn-primary w-100" disabled={isLoading}>
            로그인
          </button>
        </form>
        {/* 에러 메시지 */}
        {error && <div className="alert alert-danger mt-3">{error}</div>}
      </div>
    </div>
  );
}

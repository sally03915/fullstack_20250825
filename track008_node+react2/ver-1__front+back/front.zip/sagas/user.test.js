// npx jest sagas/user.test.js

// PS D:\hyojung\test\test1\front> npx jest sagas/user.test.js 
//  PASS  sagas/user.test.js
//   user sagas
//     √ login success (12 ms)
//     √ login failure with generic error (1 ms)
//     √ logout success (1 ms)
//     √ logout failure (1 ms)
//     √ signUp success (2 ms)
//     √ signUp failure (1 ms)
//     √ loadUsers success
//     √ loadUsers failure
//     √ updateNickname success (1 ms)
//     √ updateNickname failure
//     √ deleteUser success
//     √ deleteUser failure

// Test Suites: 1 passed, 1 total
// Tests:       12 passed, 12 total
// Snapshots:   0 total
// Time:        4.812 s
// Ran all test suites matching /sagas\\user.test.js/i.
// PS D:\hyojung\test\test1\front> 

import { call, put } from 'redux-saga/effects';
import {
  login, signUp, loadUsers, updateNickname, deleteUser, logout,
  loginAPI, signUpAPI, loadUsersAPI, updateNicknameAPI, deleteUserAPI, logoutAPI
} from '../sagas/user';
import {
  LOG_IN_REQUEST, LOG_IN_SUCCESS, LOG_IN_FAILURE,
  LOG_OUT_REQUEST, LOG_OUT_SUCCESS, LOG_OUT_FAILURE,
  SIGN_UP_REQUEST, SIGN_UP_SUCCESS, SIGN_UP_FAILURE,
  LOAD_USERS_REQUEST, LOAD_USERS_SUCCESS, LOAD_USERS_FAILURE,
  UPDATE_NICKNAME_REQUEST, UPDATE_NICKNAME_SUCCESS, UPDATE_NICKNAME_FAILURE,
  DELETE_USER_REQUEST, DELETE_USER_SUCCESS, DELETE_USER_FAILURE,
} from '../reducers/user';

describe('user sagas', () => {
  it('login success', () => {
    const action = { type: LOG_IN_REQUEST, data: { email: 'test', password: '1234' } };
    const gen = login(action);

    expect(gen.next().value).toEqual(call(loginAPI, action.data));

    const apiResponse = { APP_USER_ID: 1, EMAIL: 'test@example.com', NICKNAME: '닉네임' };
    expect(gen.next({ data: apiResponse }).value)
      .toEqual(put({
        type: LOG_IN_SUCCESS,
        data: { id: 1, email: 'test@example.com', nickname: '닉네임' },
      }));
  });

  it('login failure with generic error', () => {
    const action = { type: LOG_IN_REQUEST, data: { email: 'test', password: 'wrong' } };
    const gen = login(action);

    expect(gen.next().value).toEqual(call(loginAPI, action.data));
    const error = new Error('Network Error');
    expect(gen.throw(error).value)
      .toEqual(put({ type: LOG_IN_FAILURE, error: 'Network Error' }));
  });

  it('logout success', () => {
    const action = { type: LOG_OUT_REQUEST };
    const gen = logout(action);

    expect(gen.next().value).toEqual(call(logoutAPI));
    expect(gen.next({}).value).toEqual(put({ type: LOG_OUT_SUCCESS }));
  });

  it('logout failure', () => {
    const action = { type: LOG_OUT_REQUEST };
    const gen = logout(action);

    expect(gen.next().value).toEqual(call(logoutAPI));
    const error = { response: { data: '로그아웃 실패' } };
    expect(gen.throw(error).value)
      .toEqual(put({ type: LOG_OUT_FAILURE, error: '로그아웃 실패' }));
  });

  it('signUp success', () => {
    const action = { type: SIGN_UP_REQUEST, data: { email: 'new@test.com', password: '1234' } };
    const gen = signUp(action);

    expect(gen.next().value).toEqual(call(signUpAPI, action.data));
    expect(gen.next({}).value).toEqual(put({ type: SIGN_UP_SUCCESS }));
  });

  it('signUp failure', () => {
    const action = { type: SIGN_UP_REQUEST, data: { email: 'dup@test.com' } };
    const gen = signUp(action);

    expect(gen.next().value).toEqual(call(signUpAPI, action.data));
    const error = { response: { data: '이미 존재하는 이메일' } };
    expect(gen.throw(error).value)
      .toEqual(put({ type: SIGN_UP_FAILURE, error: '이미 존재하는 이메일' }));
  });

  it('loadUsers success', () => {
    const gen = loadUsers();

    expect(gen.next().value).toEqual(call(loadUsersAPI));

    const fakeUsers = [{ APP_USER_ID: 1, EMAIL: 'a@test.com', NICKNAME: '홍길동' }];
    expect(gen.next({ data: fakeUsers }).value)
      .toEqual(put({
        type: LOAD_USERS_SUCCESS,
        data: [{ id: 1, email: 'a@test.com', nickname: '홍길동' }],
      }));
  });

  it('loadUsers failure', () => {
    const gen = loadUsers();

    expect(gen.next().value).toEqual(call(loadUsersAPI));
    const error = { response: { data: '조회 실패' } };
    expect(gen.throw(error).value)
      .toEqual(put({ type: LOAD_USERS_FAILURE, error: '조회 실패' }));
  });

  it('updateNickname success', () => {
    const action = { type: UPDATE_NICKNAME_REQUEST, data: { id: 1, nickname: 'new' } };
    const gen = updateNickname(action);

    expect(gen.next().value).toEqual(call(updateNicknameAPI, action.data));
    expect(gen.next({}).value)
      .toEqual(put({ type: UPDATE_NICKNAME_SUCCESS, data: { id: 1, nickname: 'new' } }));
  });

  it('updateNickname failure', () => {
    const action = { type: UPDATE_NICKNAME_REQUEST, data: { id: 1, nickname: 'new' } };
    const gen = updateNickname(action);

    expect(gen.next().value).toEqual(call(updateNicknameAPI, action.data));
    const error = { response: { data: '닉네임 수정 실패' } };
    expect(gen.throw(error).value)
      .toEqual(put({ type: UPDATE_NICKNAME_FAILURE, error: '닉네임 수정 실패' }));
  });

  it('deleteUser success', () => {
    const action = { type: DELETE_USER_REQUEST, data: { id: 1 } };
    const gen = deleteUser(action);

    expect(gen.next().value).toEqual(call(deleteUserAPI, action.data.id));
    expect(gen.next({}).value)
      .toEqual(put({ type: DELETE_USER_SUCCESS, data: { id: 1 } }));
  });

  it('deleteUser failure', () => {
    const action = { type: DELETE_USER_REQUEST, data: { id: 99 } };
    const gen = deleteUser(action);

    expect(gen.next().value).toEqual(call(deleteUserAPI, action.data.id));
    const error = { response: { data: '존재하지 않는 사용자' } };
    expect(gen.throw(error).value)
      .toEqual(put({ type: DELETE_USER_FAILURE, error: '존재하지 않는 사용자' }));
  });
});

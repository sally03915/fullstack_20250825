// npx jest store/configureStore.test.js

// PS D:\hyojung\test\test1\front> npx jest store/configureStore.test.js
//  PASS  store/configureStore.test.js
//   store configuration
//     √ dispatches actions and updates state (44 ms)

// Test Suites: 1 passed, 1 total
// Tests:       1 passed, 1 total
// Snapshots:   0 total
// Time:        2.894 s, estimated 3 s
// Ran all test suites matching /store\\configureStore.test.js/i.
// PS D:\hyojung\test\test1\front> 

import { makeStore } from './configureStore';
import { LOG_IN_REQUEST, LOG_IN_SUCCESS, LOG_OUT_SUCCESS } from '../reducers/user';

describe('store configuration', () => {
  it('dispatches actions and updates state', () => {
    const store = makeStore();

    // 초기 상태 확인
    expect(store.getState().user.isLoading).toBe(false);

    // 로그인 요청 액션 dispatch
    store.dispatch({ type: LOG_IN_REQUEST });
    expect(store.getState().user.isLoading).toBe(true);

    // 로그인 성공 액션 dispatch
    const fakeUser = { id: 1, email: 'test@example.com', nickname: '홍길동' };
    store.dispatch({ type: LOG_IN_SUCCESS, data: fakeUser });
    expect(store.getState().user.me.email).toBe('test@example.com');

    // 로그아웃 성공 액션 dispatch
    store.dispatch({ type: LOG_OUT_SUCCESS });
    expect(store.getState().user.me).toBeNull();
  });
});

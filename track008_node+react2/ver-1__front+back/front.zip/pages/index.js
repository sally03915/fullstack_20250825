// pages/index.js
import { useEffect } from 'react';
import { useRouter } from 'next/router';

export default function Home() {
  const router = useRouter();
  useEffect(() => {
    router.replace('/users'); // 기본 진입 시 /users로 이동
  }, [router]);

  return null; // 화면에 아무것도 안 보여줌
}



 
// ## 🔍 1. Layout.js가 어떻게 동작
// - Next.js에서는 `pages/_app.js`가 모든 페이지의 **공통 진입점**입니다.  
// - `_app.js`에서 `<Layout>`으로 감싸주면, `Layout.js` 안에 있는 **헤더/네비게이션/푸터**가 모든 페이지에 자동으로 붙습니다.  
// - 각 페이지(`users.js`, `login.js`, `signup.js`)는 `<Layout>`의 `children`으로 들어가서 본문만 보여주게 됩니다.  
// - 즉, `Layout.js`는 **공용 틀(레이아웃)**이고, 각 페이지는 그 안에 들어가는 **본문 콘텐츠**라고 생각하면 됩니다.  

// 👉 예시 흐름  
// 1. 사용자가 `/users` 접속 → `_app.js` 실행 → `<Layout>` 렌더링.  
// 2. `Layout` 안에서 Navbar, Footer가 먼저 렌더링.  
// 3. `UsersPage` 컴포넌트가 `children`으로 들어가서 본문 영역에 표시.  
 
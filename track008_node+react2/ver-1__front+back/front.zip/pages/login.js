// pages/login.js
import { useDispatch, useSelector } from 'react-redux';
import { LOG_IN_REQUEST } from '../reducers/user';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';

export default function LoginPage() {
  const dispatch = useDispatch();
  const router = useRouter();
  const { me, isLoading, error } = useSelector((state) => state.user);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const onSubmit = (e) => {
    e.preventDefault();
    dispatch({ type: LOG_IN_REQUEST, data: { email, password } });
  };

  // 로그인 성공 시 사용자 목록 페이지로 이동
  useEffect(() => {
    if (me) {
      router.push('/users');
    }
  }, [me, router]);

  return (
    <div className="container mt-4">
      <h2 className="mb-3">로그인</h2>
      <form onSubmit={onSubmit} className="w-50 mx-auto">
        <div className="mb-3">
          <input
            type="email"
            className="form-control"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="이메일"
          />
        </div>
        <div className="mb-3">
          <input
            type="password"
            className="form-control"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="비밀번호"
          />
        </div>
        <button type="submit" className="btn btn-primary w-100" disabled={isLoading}>
          로그인
        </button>
      </form>
      {error && <div className="alert alert-danger mt-3">{error}</div>}
    </div>
  );
}

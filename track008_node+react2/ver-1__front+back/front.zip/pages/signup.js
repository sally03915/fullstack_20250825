import { useDispatch, useSelector } from 'react-redux';
import { SIGN_UP_REQUEST } from '../reducers/user';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';

export default function SignUpPage() {
  const dispatch = useDispatch();
  const router = useRouter();
  const { isLoading, error, signUpDone, me } = useSelector((state) => state.user);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [nickname, setNickname] = useState('');

  const onSubmit = (e) => {
    e.preventDefault();
    dispatch({ type: SIGN_UP_REQUEST, data: { email, password, nickname } });
  };

  // 로그인 상태면 회원가입 페이지 대신 사용자 목록으로 이동
  useEffect(() => {
    if (me) {
      router.push('/users');
    }
  }, [me, router]);

  // 회원가입 성공 시 로그인 페이지로 이동
  useEffect(() => {
    if (signUpDone) {
      router.push('/login');
    }
  }, [signUpDone, router]);

  return (
    <div className="container mt-4">
      <h2 className="mb-3">회원가입</h2>
      <form onSubmit={onSubmit} className="w-50 mx-auto">
        <div className="mb-3">
          <input type="email" className="form-control" value={email}
            onChange={(e) => setEmail(e.target.value)} placeholder="이메일" />
        </div>
        <div className="mb-3">
          <input type="password" className="form-control" value={password}
            onChange={(e) => setPassword(e.target.value)} placeholder="비밀번호" />
        </div>
        <div className="mb-3">
          <input type="text" className="form-control" value={nickname}
            onChange={(e) => setNickname(e.target.value)} placeholder="닉네임" />
        </div>
        <button type="submit" className="btn btn-primary w-100" disabled={isLoading}>
          회원가입
        </button>
      </form>
      {error && <div className="alert alert-danger mt-3">{error}</div>}
    </div>
  );
}

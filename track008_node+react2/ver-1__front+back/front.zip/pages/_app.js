// pages/_app.js
import { wrapper } from '../store/configureStore'; // Redux store 연결
import Layout from '../components/Layout';         // 공용 레이아웃 컴포넌트
import '../styles/globals.css';                    // 글로벌 CSS

function MyApp({ Component, pageProps }) {
  return (
    <Layout>
      {/* 각 페이지 컴포넌트 */}
      <Component {...pageProps} />
    </Layout>
  );
}

// next-redux-wrapper로 Redux store 연결
export default wrapper.withRedux(MyApp);

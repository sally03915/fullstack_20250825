import { useDispatch, useSelector } from 'react-redux';
import { LOAD_USERS_REQUEST, DELETE_USER_REQUEST, UPDATE_NICKNAME_REQUEST, LOG_OUT_REQUEST } from '../reducers/user';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';

export default function UsersPage() {
  const dispatch = useDispatch();
  const router = useRouter();

  const { users, isLoading, error, me } = useSelector((state) => state.user);

  const [editId, setEditId] = useState(null);
  const [newNickname, setNewNickname] = useState('');

  // 로그인 여부 체크 및 사용자 목록 불러오기
  useEffect(() => {
    if (!me) {
      router.push('/login');
    } else {
      dispatch({ type: LOAD_USERS_REQUEST });
    }
  }, [dispatch, me, router]);

  // 로그아웃 후 me가 null이 되면 로그인 페이지로 이동
  useEffect(() => {
    if (me === null) {
      router.push('/login');
    }
  }, [me, router]);

  const onDelete = (id) => {
    dispatch({ type: DELETE_USER_REQUEST, data: { id } });
  };

  const onEdit = (id) => {
    setEditId(id);
  };

  const onUpdateNickname = (id) => {
    dispatch({ type: UPDATE_NICKNAME_REQUEST, data: { id, nickname: newNickname } });
    setEditId(null);
    setNewNickname('');
  };

  const onLogout = () => {
    dispatch({ type: LOG_OUT_REQUEST });
  };

  return (
    <div className=""> 
      <div className="p-5 bg-primary text-white text-center">
        <h1>사용자 목록 페이지</h1>
        <p>로그인 후만 접근 가능</p> 
      </div>

      <nav className="navbar navbar-expand-sm bg-dark navbar-dark">
        <div className="container-fluid">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link href="/users"><a className="nav-link text-white">Home</a></Link>
            </li>
            {!me ? (
              <>
                <li className="nav-item"><Link href="/login"><a className="nav-link text-white">로그인</a></Link></li>
                <li className="nav-item"><Link href="/signup"><a className="nav-link text-white">회원가입</a></Link></li>
              </>
            ) : (
              <li className="nav-item">
                <button className="btn btn-link nav-link text-white" onClick={onLogout}>
                  로그아웃
                </button>
              </li>
            )}
          </ul>
        </div>
      </nav>
  
      <div className="container mt-4">
        <h1 className="mb-3">사용자 목록</h1>

        {isLoading && <div className="alert alert-info">로딩 중...</div>}
        {error && <div className="alert alert-danger">{error}</div>}

        <table className="table table-striped table-bordered table-hover">
          <thead>
            <tr>
              <th>이메일</th>
              <th>닉네임</th>
              <th>액션</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id}>
                <td>{u.email}</td>
                <td>
                  {editId === u.id ? (
                    <input
                      className="form-control"
                      value={newNickname}
                      onChange={(e) => setNewNickname(e.target.value)}
                      placeholder="새 닉네임"
                    />
                  ) : (
                    u.nickname
                  )}
                </td>
                <td>
                  {editId === u.id ? (
                    <button
                      className="btn btn-success btn-sm me-2"
                      onClick={() => onUpdateNickname(u.id)}
                    >
                      수정 완료
                    </button>
                  ) : (
                    <button
                      className="btn btn-primary btn-sm me-2"
                      onClick={() => onEdit(u.id)}
                    >
                      닉네임 수정
                    </button>
                  )}
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => onDelete(u.id)}
                  >
                    삭제
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

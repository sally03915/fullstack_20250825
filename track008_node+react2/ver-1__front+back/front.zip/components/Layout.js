// components/Layout.js
import Link from 'next/link';
import { useDispatch, useSelector } from 'react-redux';
import { LOG_OUT_REQUEST } from '../reducers/user';

export default function Layout({ children }) {
  const dispatch = useDispatch();
  const { me } = useSelector((state) => state.user);

  const onLogout = () => {
    dispatch({ type: LOG_OUT_REQUEST });
  };

  return (
    <div>
      {/* 헤더 */}
      <div className="p-5 bg-primary text-white text-center">
        <h1>공용 레이아웃 헤더</h1>
      </div>

      {/* 네비게이션바 */}
      <nav className="navbar navbar-expand-sm bg-dark navbar-dark">
        <div className="container-fluid">
          <ul className="navbar-nav">
            <li className="nav-item"><Link href="/users"><a className="nav-link text-white">Home</a></Link></li>
            {!me ? (
              <>
                <li className="nav-item"><Link href="/login"><a className="nav-link text-white">로그인</a></Link></li>
                <li className="nav-item"><Link href="/signup"><a className="nav-link text-white">회원가입</a></Link></li>
              </>
            ) : (
              <li className="nav-item">
                <button className="btn btn-link nav-link text-white" onClick={onLogout}>
                  로그아웃
                </button>
              </li>
            )}
          </ul>
        </div>
      </nav>

      {/* 본문 */}
      <main className="container mt-4">{children}</main>

      {/* 푸터 */}
      <footer className="bg-dark text-white text-center p-3 mt-5">
        © 2025 My App
      </footer>
    </div>
  );
}
